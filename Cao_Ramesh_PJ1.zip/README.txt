Author: Tinh Cao, Uday Ramesh
-------------------------------------------------------------------------------
To run step 1 of the project, use main.py file. Step 2 and step 3 are stored in
2 different Jupyter Notebook name "Twitter_Analysis.ipynb" and
"degree-of-distributions.ipynb" accordingly. 
